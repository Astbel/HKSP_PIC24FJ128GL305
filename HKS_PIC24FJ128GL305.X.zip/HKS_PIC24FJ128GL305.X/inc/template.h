#ifndef TEMPLATE_H
#define	TEMPLATE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* TEMPLATE_H */